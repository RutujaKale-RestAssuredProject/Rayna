package Config;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class URLs {
	WebDriver driver;
	
	public URLs(WebDriver d) {
		driver =d;
	}

	public void UAT_url () {		
		driver.get("https://app.eexchange.ae:4001/eExchange/login/loggedinPage.action");
	}
	
	public void Test_url () {		
		driver.get("https://app.eexchange.ae:5001/eExchange/login/loggedinPage.action");
	}

}