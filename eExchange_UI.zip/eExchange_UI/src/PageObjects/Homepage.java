package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Homepage {
	WebDriver driver;
	
	public Homepage(WebDriver d) {
		driver =d;
	}
	
	public void MyProfileMenu () {		
		//My profile
		driver.findElement(By.xpath("(//*[contains(text(),'My Profile')])[1]")).click();		
	}

}
