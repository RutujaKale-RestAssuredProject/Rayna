package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import ExcelResults.Xls_Reader;

public class AddBankAccount {
	WebDriver driver;
	
	public AddBankAccount(WebDriver d) {
		driver =d;
	}

	public void Addbankacc () throws InterruptedException {		
		driver.findElement(By.xpath("(//*[contains(text(),'Add Bank Account')])[1]")).click();
		
		WebElement accName = driver.findElement(By.id("accName"));
		WebElement accNumber = driver.findElement(By.id("accNumber"));
		WebElement bankBranch = driver.findElement(By.id("bankBranch"));		
		
		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		
		String sheetName = "BankAccountDetails";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AccountName = reader.getCellData(sheetName, "accName", rowNum);
			String AccountNumber = reader.getCellData(sheetName, "accNumber", rowNum);
			String BankBranchName = reader.getCellData(sheetName, "bankBranch", rowNum);

			accName.sendKeys(AccountName);
			accNumber.sendKeys(AccountNumber);
			bankBranch.sendKeys(BankBranchName);
			
			driver.findElement(By.id("updateAccount")).click();
			Thread.sleep(10000);
		}
	}

}