package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ExcelResults.Xls_Reader;

public class Login {
	WebDriver driver;
	
	public Login(WebDriver d) {
		driver =d;
	}

	public void login_process () throws InterruptedException {		
		//Valid Login
		WebElement userName = driver.findElement(By.id("userId"));
		WebElement pwd = driver.findElement(By.id("password"));
		Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
		driver.findElement(By.id("rememberID")).click();
		
		String sheetName = "login";

		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String UserName = reader.getCellData(sheetName, "userId", rowNum);
			String Password = reader.getCellData(sheetName, "password", rowNum);

			//System.out.println(UserName + " " + Password);
			userName.sendKeys(UserName);
			pwd.sendKeys(Password);

			driver.findElement(By.xpath("(.//*[@class='login-button'])[1]")).click();
			Thread.sleep(10000);
			System.out.println("User is Successfully Logged In!");
		}
	}

}