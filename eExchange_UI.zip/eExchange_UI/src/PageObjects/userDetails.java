package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class userDetails {
	WebDriver driver;
	
	public userDetails(WebDriver d) {
		driver =d;
	}

	public void User_Details () {		
		driver.findElement(By.id("first-name")).sendKeys("Rutuja");
		driver.findElement(By.id("last-name")).sendKeys("Vichare");
		driver.findElement(By.id("postal-code")).sendKeys("000000");
	}

}