package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import ExcelResults.Xls_Reader;

public class ViewBankAccount {
	WebDriver driver;
	
	public ViewBankAccount(WebDriver d) {
		driver =d;
	}

	public void ViewBank () throws InterruptedException {		
	
    driver.findElement(By.xpath("(//*[contains(text(),'View Bank Account')])[1]")).click();
    
    //search for the bank account
    driver.findElement(By.xpath("//*[@type='search']")).sendKeys("");
    
	WebElement accName = driver.findElement(By.id("accName"));	
	WebElement accNumber = driver.findElement(By.id("accNumber"));	
	WebElement bankBranch = driver.findElement(By.id("bankBranch"));	
	
	Xls_Reader reader = new Xls_Reader("./src/ExcelResults/SampleExcel.xlsx");
	
	String sheetName = "BankAccountDetails";

	int rowCount = reader.getRowCount(sheetName);

	for(int rowNum=2; rowNum<=rowCount; rowNum++){
		String AccountName = reader.getCellData(sheetName, "accName", rowNum);
		String AccountNumber = reader.getCellData(sheetName, "accNumber", rowNum);
		String BankBranchName = reader.getCellData(sheetName, "bankBranch", rowNum);
		
		//Search with Account Number
		WebElement Search = driver.findElement(By.xpath("//*[@type='search']"));
		Search.sendKeys(AccountNumber);
		Thread.sleep(10000);				
		
		String AccountHolderName = driver.findElement(By.xpath("(.//*[@class='white'])[1]")).toString();
		Assert.assertEquals(AccountHolderName, AccountName);
		
		System.out.println("The Bank Account is displayed for the searched value!");
		
	}
  }
}