package ExcelResults;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {
 
 public void writeExcel(String sheetName, String cellvalue, int row, int col) throws Exception {
  
  String excelPath="D:\\Testing\\Testing.xlsx";
  
  File file= new File(excelPath);
  
  FileInputStream fis= new FileInputStream(file);
  
  XSSFWorkbook wb= new XSSFWorkbook(fis);
  
  XSSFSheet sheet= wb.getSheet(sheetName);
  
  XSSFCell Cell;
  XSSFRow Row;
  
  try
  {


      Row  = sheet.createRow(row);

      Cell = Row.getCell(col);

      if (Cell == null) {

          Cell = Row.createCell(col);

          Cell.setCellValue(cellvalue);

          } else {

              Cell.setCellValue(cellvalue);

          }
  
  //sheet.getRow(row).createCell(col).setCellValue(cellvalue);
  
  FileOutputStream fos= new FileOutputStream(new File(excelPath));
  
  wb.write(fos);
  
  wb.close();
  
  fos.close(); 
  
  }
  catch (Exception e)
  {
      e.printStackTrace();
  }  
}
}
