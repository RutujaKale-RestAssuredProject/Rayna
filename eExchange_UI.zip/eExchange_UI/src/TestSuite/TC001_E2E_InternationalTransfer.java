package TestSuite;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import Config.URLs;
import ExcelResults.Xls_Reader;
//import com.excel.lib.util.Xls_Reader;
import PageObjects.userDetails;
import PageObjects.Login;
import PageObjects.ViewBankAccount;
import PageObjects.AddBankAccount;
import PageObjects.Homepage;

public class TC001_E2E_InternationalTransfer {

	public WebDriver driver;

	@Parameters("browser")
	@BeforeClass
	public void BeforeTest(String browser) throws Exception {

		// Check if parameter passed from TestNG is 'Firefox'
		if (browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver",
					"C:\\Users\\rutuja.kale\\Desktop\\Eclipse\\drivers\\geckodriver.exe");
			// create Firefox instance
			driver = new FirefoxDriver();
		}
		// Check if parameter passed from TestNG is 'Chrome'
		else if (browser.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\rutuja.kale\\Desktop\\Eclipse\\drivers\\chromedriver.exe");
			// create chrome instance
			driver = new ChromeDriver();
		}
		// Check if parameter passed from TestNG is 'Edge'
		else if (browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver",
					"C:\\Users\\rutuja.kale\\Desktop\\Eclipse\\drivers\\msedgedriver.exe");
			// create Internet Explorer instance
			driver = new EdgeDriver();
		}

		else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 0)
	// Once Before method is completed, Test method will start
	public void login() throws InterruptedException, IOException {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Login login = new Login(driver);
		URLs url = new URLs(driver);

		// Call URL
		url.UAT_url();
		System.out.println("Test URL for e-Exchange is opened!");

		driver.manage().window().maximize();
		Thread.sleep(10000);

		// Login
		login.login_process();
		Thread.sleep(10000);
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement Logo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("countryCodeIdMob")));
		Logo.isDisplayed();
		Thread.sleep(10000);
			
		// Logged in Screenshot
		File UserProfileLoggedIn = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(UserProfileLoggedIn,
				new File("S:/Rutuja/Test Automation/Screenshots/UserProfileLoggedIn.jpg"));
		Thread.sleep(5000);
	}

	@Test(priority = 1)
	// Once Before method is completed, Test method will start
	public void MyProfile() throws InterruptedException, IOException {

		AddBankAccount AddBank = new AddBankAccount(driver);
		ViewBankAccount ViewBank = new ViewBankAccount(driver);
		Homepage HomePg = new Homepage(driver);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		// My Profile --> Add Bank Account
		HomePg.MyProfileMenu();
		AddBank.Addbankacc();

		HomePg.MyProfileMenu();
		ViewBank.ViewBank();
	}

	@AfterClass
	public void afterTest() {
		/*
		 * driver.quit(); System.out.println("<<<<<<The browser is closed>>>>>>");
		 */
	}
}