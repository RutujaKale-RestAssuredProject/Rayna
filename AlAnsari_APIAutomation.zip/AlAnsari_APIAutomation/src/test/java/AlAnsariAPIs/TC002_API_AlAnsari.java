package AlAnsariAPIs;

import static io.restassured.RestAssured.given;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

@Description("GET Method ---> Test Case - Fetch Customer Info - ext-sms - Test 22")

public class TC002_API_AlAnsari {
	
	@BeforeTest
    public static void setup() {
        RestAssured.baseURI = "http://172.18.10.22:8089";
    }

	@Test
	public void getRequestWithQueryParam() {
        Response response = given()
                .contentType(ContentType.JSON)
                .header("Authorization", "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJkZW1vIiwiY2xpZW50SWQiOiJBQUVfVEVTVCIsImV4cCI6MTY3OTQ4MzI2NiwiaWF0IjoxNjc5NDY1MjY2fQ.AShegc0xKD6gdBogcoMQ_6Y40uHA6vr5EkS999iccaAUCvBrujsdAO47CxE3r9Gtad5LTuOQYY4apckxpIWnQQ")
                .param("mobNumber", "971559155870")
                .when()
                .get("/ext-sms-integration/customers/customerinfo")
                .then()
                .extract().response();
        
		String res = response.body().asString();
		System.out.println("---------------->" + res);

		// Creating an instance of file
		Path path = Paths.get("S:\\Rutuja\\Test Automation\\Rest Assured\\Logs\\TC002_API_AlAnsari.txt");

		try {
			// Now calling Files.writeString() method
			// with path , content & standard charsets
			Files.writeString(path, res, StandardCharsets.UTF_8);
		}

		// Catch block to handle the exception
		catch (IOException ex) {
			// Print message exception occurred as
			// invalid. directory local path is passed
			System.out.print("Invalid Path");
		}

	}
}