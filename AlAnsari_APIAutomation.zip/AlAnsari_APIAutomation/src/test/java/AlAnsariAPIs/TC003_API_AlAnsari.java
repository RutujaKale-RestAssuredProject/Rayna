package AlAnsariAPIs;

import static io.restassured.RestAssured.given;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Description("POST Method ---> Test Case - Al Marya Account Enquiry _ TEST 12")

public class TC003_API_AlAnsari {
	
	@BeforeTest
	public static void main(String args[]) {

		AlAnsariAPI_03();
	}
    	
    @Test
    public static void AlAnsariAPI_03() {
    	
	System.setProperty("webdriver.chrome.silentOutput", "true");
 
	File newUserXmlFile = new File("S:\\Rutuja\\Test Automation\\Rest Assured\\Input files\\TC003_API_AlAnsari.xml");
    
    Response response = given()
        		.header("Content-type", "application/xml")
        		.and()
        		.body(newUserXmlFile)
        		.when()
        		.post("http://172.18.10.12:8085/AREXINTEGRATION/AlMaryahAccountEnquiryService")
        		.then()
                .extract().response();
        
	String res = response.body().asString();
	System.out.println("---------------->" + res);

	// Creating an instance of file
	Path path = Paths.get("S:\\Rutuja\\Test Automation\\Rest Assured\\Logs\\TC003_API_AlAnsari.xml");

	try {
			// Now calling Files.writeString() method
			// with path , content & standard charsets
			Files.writeString(path, res, StandardCharsets.UTF_8);
	}

	// Catch block to handle the exception
	catch (IOException ex) {
			// Print message exception occurred as
			// invalid. directory local path is passed
			System.out.print("Invalid Path");
		}
	}	
}
