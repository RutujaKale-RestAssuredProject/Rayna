package AlAnsariAPIs;

import static io.restassured.RestAssured.given;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.mozilla.javascript.Context;
import org.springframework.context.annotation.Description;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

@Description("POST Method ---> Test Case - Token - user demo - ext-sms - Test 22")

public class TC004_API_AlAnsari_Combined {

	@Test
	// This will fetch the response body as is and log it. given and when are
	// optional here
	public void AlAnsariAPI_01(ITestContext context) {

		System.setProperty("webdriver.chrome.silentOutput", "true");

		String InputJson = "{\r\n" + "  \"username\": \"demo\",\r\n"
				+ "  \"password\": \"$2a$10$f1nNyZEa/5xp66ScaBt4COlcDWzSBNlxA2sBcX7TqwJxyqpKP8nq2\"\r\n" + "}\r\n" + "";

		RestAssured.baseURI = "http://172.18.10.22:8089";

		String token = RestAssured
				.given()
				.header("Content-type", "application/json")
				.header("clientId", "AAE_TEST")
				.and()
				.body(InputJson)
				.when()
				.post("/ext-sms-integration/login")
				.then()
				.extract().response()
				.jsonPath()
				.get("token");
		
		// Storing data in a context to use for other tests
		context.setAttribute("token", token);
	}
	
	@Description("GET Method ---> Test Case - Fetch Customer Info - ext-sms - Test 22")
	@Test
	public void AlAnsariAPI_02(ITestContext context) {
		// Retrieving required data from context
		String token = (String) context.getAttribute("token");

        RestAssured.baseURI = "http://172.18.10.22:8089";

		Response response = given()
	                .contentType(ContentType.JSON)
	                .header("Authorization", token)
	                .param("mobNumber", "971559155870")
	                .when()
	                .get("/ext-sms-integration/customers/customerinfo")
	                .then()
	                .extract().response();
		
		String res = response.body().asString();
		System.out.println("---------------->" + res);
		
		// Creating an instance of file
		Path path = Paths.get("S:\\Rutuja\\Test Automation\\Rest Assured\\Logs\\TC004_API_AlAnsari.txt");

		try {
			// Now calling Files.writeString() method
			// with path , content & standard charsets
			Files.writeString(path, res, StandardCharsets.UTF_8);
		}

		// Catch block to handle the exception
		catch (IOException ex) {
			// Print message exception occurred as
			// invalid. directory local path is passed
			System.out.print("Invalid Path");
		}
		
		
	}
}