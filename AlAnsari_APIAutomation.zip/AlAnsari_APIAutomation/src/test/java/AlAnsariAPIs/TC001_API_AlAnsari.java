package AlAnsariAPIs;

import static io.restassured.RestAssured.given;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.mozilla.javascript.Context;
import org.springframework.context.annotation.Description;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Description("POST Method ---> Test Case - Token - user demo - ext-sms - Test 22")

public class TC001_API_AlAnsari {

	@BeforeTest
	public static void main(String args[]) {

		AlAnsariAPI_01();
	}

	@Test
	// This will fetch the response body as is and log it. given and when are
	// optional here
	public static void AlAnsariAPI_01() {

		System.setProperty("webdriver.chrome.silentOutput", "true");

		String InputJson = "{\r\n" + "  \"username\": \"demo\",\r\n"
				+ "  \"password\": \"$2a$10$f1nNyZEa/5xp66ScaBt4COlcDWzSBNlxA2sBcX7TqwJxyqpKP8nq2\"\r\n" + "}\r\n" + "";

		RestAssured.baseURI = "http://172.18.10.22:8089";

		Response response = given()
				.header("Content-type", "application/json")
				.header("clientId", "AAE_TEST")
				.and()
				.body(InputJson)
				.when()
				.post("/ext-sms-integration/login")
				.then()
				.extract().response();

		//Store at local repository
		String res = response.body().asString();
		System.out.println("---------------->" + res);

		// Creating an instance of file
		Path path = Paths.get("S:\\Rutuja\\Test Automation\\Rest Assured\\Logs\\TC001_API_AlAnsari.txt");

		try {
			// Now calling Files.writeString() method
			// with path , content & standard charsets
			Files.writeString(path, res, StandardCharsets.UTF_8);
		}

		// Catch block to handle the exception
		catch (IOException ex) {
			// Print message exception occurred as
			// invalid. directory local path is passed
			System.out.print("Invalid Path");
		}

	}
}