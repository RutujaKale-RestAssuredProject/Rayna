package RaynaB2B_API_HotelAPIs;

import static io.restassured.RestAssured.given;
import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;


@Description("Test Case - API Automation for Hotel Availability API")


public class TestCase_001_API_HotelCount_March {
	
@BeforeTest
   public static void main(String args[]) {
 
     HotelCount_March ();
}

@Test
   //This will fetch the response body as is and log it. given and when are optional here
   public static void HotelCount_March() {
	
	System.out.println("TestCase_001_API_HotelCount_March is Started");
	
	String InputJson = "{\r\n"
			+ "    \"Token\":\"eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIzODllNWEzNS05OTJkLTRjYzMtYjVjYy04YmZjNmZlY2E2MmMiLCJVc2VySWQiOiIzNTkwNiIsIlVzZXJUeXBlIjoiQWdlbnQiLCJQYXJlbnRJRCI6IjAiLCJFbWFpbElEIjoibWF5dXJpLnBAdGVjaG5vaGVhdmVuLmNvbSIsImlzcyI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSIsImF1ZCI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSJ9.TR-aA10804jrF9VQNDgOBpq56fVySNMhpn5oRJ12gic\",\r\n"
			+ "    \"Request\": {\r\n"
			+ "        \"Rooms\": [\r\n"
			+ "            {\r\n"
			+ "                \"RoomNo\": 1,\r\n"
			+ "                \"NoofAdults\": 2,\r\n"
			+ "                \"NoOfChild\": 0,\r\n"
			+ "                \"ChildAge\": []\r\n"
			+ "            }\r\n"
			+ "        ],\r\n"
			+ "        \"CityID\": \"212101\",\r\n"
			+ "        \"CheckInDate\": \"03-01-2022\",\r\n"
			+ "        \"CheckOutDate\": \"03-02-2022\",\r\n"
			+ "        \r\n"
			+ "        \"NoofNights\": \"1\",\r\n"
			+ "        \"Nationality\": \"India\",\r\n"
			+ "        \"Filters\": {\r\n"
			+ "            \"IsRecommendedOnly\": \"0\",\r\n"
			+ "            \"IsShowRooms\": \"0\",\r\n"
			+ "            \"IsOnlyAvailable\": \"1\",\r\n"
			+ "            \"StarRating\": {\r\n"
			+ "                \"Min\": 1,\r\n"
			+ "                \"Max\": 5\r\n"
			+ "            },\r\n"
			+ "            \"HotelIds\": \"\"\r\n"
			+ "        }\r\n"
			+ "    },\r\n"
			+ "    \"AdvancedOptions\": {\r\n"
			+ "        \"Currency\": \"AED\"\r\n"
			+ "    }\r\n"
			+ "}";
	

	        RestAssured.baseURI = "http://raynaapi.raynatours.com";

	        Response response = given()
	                .header("Content-type", "application/json")
	                .and()
	                .body(InputJson)
	                .when()
	                .post("/api/XConnect/Availability")
	                .then()
	                .extract().response();	
	        
	        System.out.println(response.asPrettyString());
	        System.out.println(response.getBody().asString());
	        System.out.printf("The Response Time is ");
	        System.out.println(response.getTime());	
	        System.out.println("Hotel Count Search for March - PASSED");
	
	        System.out.println("TestCase_001_API_HotelCount_March is Finished");

}


}
