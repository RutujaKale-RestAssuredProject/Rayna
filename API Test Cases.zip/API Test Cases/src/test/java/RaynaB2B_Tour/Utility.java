package RaynaB2B_Tour;

public class Utility {
	
	  public static final String Authorization = "Bearer eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5MDAxNjZkNS1kNGU4LTQ1MmYtYTA0MS0yMDcxZGRjZjliMGIiLCJVc2VySWQiOiIzNTkwNiIsIlVzZXJUeXBlIjoiQWdlbnQiLCJQYXJlbnRJRCI6IjAiLCJFbWFpbElEIjoibWF5dXJpLnBAdGVjaG5vaGVhdmVuLmNvbSIsImlzcyI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSIsImF1ZCI6Imh0dHA6Ly9yYXluYWFwaS5yYXluYXRvdXJzLmNvbSJ9.2UXaCE8VbiaUqvNWhG7JjSVqqH6PlE7zh_5J6-nijN0";
	
	  public static final String BaseURI = "http://raynaapi.raynatours.com";	  
}
