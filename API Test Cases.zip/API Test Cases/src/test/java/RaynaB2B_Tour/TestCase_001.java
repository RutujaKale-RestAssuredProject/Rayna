package RaynaB2B_Tour;

import static io.restassured.RestAssured.given;
import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Description("Test Case - API Automation for TourList API")

public class TestCase_001 {

	@BeforeTest
	   public static void main(String args[]) {
		
		
	     getResponseBody();
	}

	@Test
	   //This will fetch the response body as is and log it. given and when are optional here
	   public static void getResponseBody(){
		
		String InputJson = "{\r\n"
				+ "    \"countryId\":13063,\r\n"
				+ "    \"cityId\":13668, \r\n"
				+ "    \"travelDate\": \"02-18-2023\"\r\n"
				+ "}";
		

		        RestAssured.baseURI = Utility.BaseURI;

		        Response response = given().contentType("application/json")
		                .header("Authorization", Utility.Authorization)
		                .and()
		                .body(InputJson)
		                .when()
		                .post("/api/Tour/tourlist")
		                .then()
		                .extract().response();
		        
		        System.out.println(response.asPrettyString());
		        System.out.println(response.getBody().asString());
		        System.out.printf("The Response Time is ");
		        System.out.println(response.getTime());	
		        System.out.println("TourList API - PASSED");
	    
	   }

}
