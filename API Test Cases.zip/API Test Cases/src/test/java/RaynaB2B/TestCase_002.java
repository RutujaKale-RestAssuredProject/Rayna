package RaynaB2B;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

@Test
public class TestCase_002 {

	public static void main(String[] args) throws InterruptedException {

			 SearchRoomAvailability();
		}		  


	@Test(priority=0)
	private static void SearchRoomAvailability() throws InterruptedException {
	   
		//Launching the chrome browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rutuj\\Desktop\\Selenium\\chrome\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.raynab2b.com/");
        
        Thread.sleep(5000);
        
        //Login
     	driver.findElement(By.id("txtAgentcode")).sendKeys("AGT-26565");
     	driver.findElement(By.id("txtUsername")).sendKeys("mayuri.p@technoheaven.com");
     	driver.findElement(By.id("txtPassword")).sendKeys("techno@123");
     	driver.findElement(By.id("btnLogin")).click();
     	
     	Thread.sleep(5000);
     	
     	//Add to cart all items
     	driver.findElement(By.id("HotelLink")).click(); //Click on Hotel Link
     	Thread.sleep(5000);
     	
     	driver.findElement(By.id("txtCityName")).sendKeys("Dubai"); //Enter City Name as Dubai
     	Thread.sleep(5000);
     	
     	driver.findElement(By.xpath("//select[@id='ddlNationality']/option[@value='Indian']")).click();
     	Thread.sleep(5000);
     	
     	driver.findElement(By.id("btnHotelSearch")).click(); //Click on Search Button for Hotels
     	Thread.sleep(10000);
     	
     	WebDriverWait wait = new WebDriverWait(driver, 10);
     	WebElement PriceLoading = wait.until(
     	        ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
     	PriceLoading.isDisplayed();
     	
     	driver.findElement(By.xpath("//select[@id='ddlSortOption']/option[@value='1']")).click();
     	Thread.sleep(5000);
     	
     	WebElement HotelCount = driver.findElement(By.id("hotelcount"));
     	System.out.printf("Hotel Count Searched is ");
     	System.out.printf(HotelCount.getText());
        
     	driver.getTitle();
        Thread.sleep(5000);
        
        driver.findElement(By.id("hotelsearchtext")).sendKeys("Maisan Hotel");
     	
        //Search for Landmark Hotel
        WebElement HotelName1 = wait.until(
     	        ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='htlHotelName'][contains(text(),'Maisan Hotel')]")));
     	System.out.println(HotelName1.getText());
     	
     	WebElement SelectHotel1 = wait.until(
     	        ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='htlHotelName'][contains(text(),'Maisan Hotel')]/following::div/div/div/div/a[1]")));
     	SelectHotel1.isDisplayed();
     	SelectHotel1.click();
     	System.out.println("Maisan Hotel is Selected");
     	
     	//Get the count of Rooms from the Hotel
     	/*//Select more RoomTypes
     	driver.findElement(By.xpath("//span[@class='htlHotelName'][contains(text(),'Maisan Hotel')]/following::div[@class='bottomContent']/div/a[@id='showmore_Room']")).click();
     	*/
     	Thread.sleep(5000);
     	
     	List<WebElement> RoomCount = driver.findElements(By.xpath("//div[@class='TourOP']"));
     	System.out.println(RoomCount.size());
     	
     	Thread.sleep(5000);
     	
     	//Verify the Price for each Rooms
     	WebElement Room1 = driver.findElement(By.xpath("//div[@class='TourOP']"));
     	System.out.println(Room1.getText());
     	WebElement Price1 = driver.findElement(By.xpath("//div[@class='TourOP']/following::td[@class='Tnightprice']"));
     	System.out.println(Price1.getText());
     	
     	WebElement Room2 = driver.findElement(By.xpath("//div[@class='TourOP']/following::tbody/tr/td/div[@class='TourOP']"));
     	System.out.println(Room2.getText());
     	WebElement Price2 = driver.findElement(By.xpath("//div[@class='TourOP']/following::tbody/tr/td/div[@class='TourOP']/following::td[@class='Tnightprice']"));
     	System.out.println(Price2.getText());
     	
     	Thread.sleep(5000);
     	
     	//Logout
     	driver.findElement(By.id("liprofile")).click();
     	driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
    	Thread.sleep(5000);
    	
    	driver.close();
    	driver.quit();
    	
    	System.out.println("Web Automation for Room count by Hotel - PASSED");
	}
	
}
