package RaynaB2B;

import static io.restassured.RestAssured.given;
import org.json.JSONObject;
import org.springframework.context.annotation.Description;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;


@Description("Test Case - API Automation for Hotel Count")


public class TestCase_003 {
	
@BeforeTest
   public static void main(String args[]) {
	
	
     getResponseBody();
}

@Test
   //This will fetch the response body as is and log it. given and when are optional here
   public static void getResponseBody(){
	

   JSONObject json = new JSONObject();
   json.put("Token", "eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJkZGEyMDlmNy0wYThiLTQyN2UtOWU3Zi1kMTExZDNjZjM5ZWYiLCJVc2VySWQiOiIyMzY4MCIsIlVzZXJUeXBlIjoiQWdlbnQiLCJQYXJlbnRJRCI6IjAiLCJFbWFpbElEIjoiYW1tYXJAd2l0aGluZWFydGguY29tIiwiaXNzIjoiaHR0cDovL3JheW5hYXBpLnJheW5hdG91cnMuY29tIiwiYXVkIjoiaHR0cDovL3JheW5hYXBpLnJheW5hdG91cnMuY29tIn0.S90eAJ9xprnpD3wqHfUqm1bLipKhWkcK68n2O2titt8"); 
   json.put("Request.CityId", "212101"); 
   
   
 given()
   .header("Content-Type", "application/json")
   .contentType(ContentType.JSON)
   .accept(ContentType.JSON)
   .body(json.toString())
   
 .when()
   .post("http://raynaapi.raynatours.com/api/XConnect/AllHotelsByCity")
   
 .then().statusCode(200);
    
   }

}
