package RaynaB2B_UI_HotelAPIs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

@Test
public class TestCase_003_UI_HotelCount_May {

	public static void main(String[] args) throws InterruptedException {

			 SearchHotelCount_May();
		}		  


	@Test(priority=0)
	private static void SearchHotelCount_May() throws InterruptedException {
	   
		//Launching the chrome browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rutuj\\Desktop\\Selenium\\chrome\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.raynab2b.com/");       
        Thread.sleep(5000);
        
        //Login
     	driver.findElement(By.id("txtAgentcode")).sendKeys("AGT-26565");
     	driver.findElement(By.id("txtUsername")).sendKeys("mayuri.p@technoheaven.com");
     	driver.findElement(By.id("txtPassword")).sendKeys("techno@123");
     	driver.findElement(By.id("btnLogin")).click();  	
     	Thread.sleep(10000);

     	driver.findElement(By.id("HotelLink")).click(); //Click on Hotel Link
     	Thread.sleep(5000);
     	
     	//Filters
     	driver.findElement(By.id("txtCityName")).sendKeys("Dubai"); //Enter City Name as Dubai
     	Thread.sleep(5000);    	
     	driver.findElement(By.xpath("//select[@id='ddlNationality']/option[@value='Indian']"));;
     	Thread.sleep(5000);   	
     	driver.findElement(By.id("txtCheckinDate")).click();
     	driver.findElement(By.xpath("//li[@id='month-year-4-2022']")).click();
     	Thread.sleep(5000);
     	driver.findElement(By.xpath(".//ul[@id='month-wrap-txtCheckinDate']/li[@id='1-5-2022']")).click();
     	Thread.sleep(5000);    	
     	driver.findElement(By.id("txtCheckoutDate")).click();
     	driver.findElement(By.xpath(".//ul[@id='month-wrap-txtCheckoutDate']/li[@id='2-5-2022']")).click();
     	Thread.sleep(5000);
     	 
     	driver.findElement(By.id("btnHotelSearch")).click(); //Click on Search Button for Hotels
     	Thread.sleep(10000);
     	
     	WebDriverWait wait = new WebDriverWait(driver, 10);
     	WebElement PriceLoading = wait.until(
     	        ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='PriceBoxRight']")));
     	PriceLoading.isDisplayed();
     	
     	driver.findElement(By.xpath("//select[@id='ddlSortOption']/option[@value='1']")).click();     	
     	Thread.sleep(5000);
     	
     	WebElement HotelCount = driver.findElement(By.id("hotelcount"));    
     	System.out.println(HotelCount.getText());
     	
     	driver.getTitle();
     	Thread.sleep(5000);
     	
     	driver.findElement(By.id("liprofile")).click();
     	driver.findElement(By.xpath("//a[@href='/Signout.aspx']")).click();
    	Thread.sleep(5000);
    	
    	driver.close();
    	driver.quit();
    	
		
	}
	
}
